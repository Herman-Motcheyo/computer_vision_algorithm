h=zeros(1,8);
for i=1:4 
  for j=1:4 
    h(M(i,j)+1)+;
  end;
end;
M
h
